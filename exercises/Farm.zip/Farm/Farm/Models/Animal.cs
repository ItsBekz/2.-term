﻿namespace FarmMVC.Models
{
    public class Animal
    {
        public int animalId { get; set; }
        public string? species { get; set; }
        public int? weight { get; set; }
    }
}
