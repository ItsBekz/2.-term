﻿namespace FarmMVC.Models
{
    public class Owner
    {
        public int id { get; set; }
        public string? name { get; set; }
        public string myAnimal { get; set; }

    }
}
